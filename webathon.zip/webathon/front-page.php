<?php get_header(); ?>
        <!-- Banner -->
        <div id="banner">
                <img src="<?php bloginfo('template_directory'); ?>/images/Webathon_lumberjack man.png" alt="alt text" /> 
                
                <div class="discription">
                    <h2>your new website
                    <br />
                    solution 
                    </h2>
                        
                    <span class="text"> Beacome <a href="#">succesfull</a> with our</br>integrated web packages</span>
</br><a href="#" class="button">Learn more</a>
                </div>
        </div>

    </div>
</div>

<!-- Main Wrapper -->
<div id="main-wrapper">
    <div class="wrapper style1">
        <div class="inner">


                         <div id="servicecmsblock" class="block service" > 
                        <div class="container">	
                        <div class="row">
                        <div class="col-4 col-6-medium col-12-small">
                            <div class="ser_wrap_one">
                                <div class="service-image">
                                        <img src="<?php bloginfo('template_directory'); ?>/images/Webathon_segment.png" alt="alt text" />
                                </div>

                                <div class="service-text">
                                    <div class="text"><strong>Segment</strong> your data</br> effectively</div>
                                </div>
                            </div>
                        </div>
                        <div class="col-4 col-6-medium col-12-small">
                        <div class="ser_wrap">
                                <div class="service-image">
                                        <img src="<?php bloginfo('template_directory'); ?>/images/Webathon_distribute.png" alt="alt text" />
                                </div>

                                <div class="service-text">
                                <div class="text"><strong>Distribute</strong> tasks</br> to your team</div>
                                </div>
                                </div>
                        </div>
                        <div class="col-4 col-6-medium col-12-small">
                        <div class="ser_wrap_three">
                                <div class="service-image">
                                        <img src="<?php bloginfo('template_directory'); ?>/images/Webathon_manage.png" alt="alt text" />
                                </div>

                                <div class="service-text">
                                <div class="text"><strong>Manage</strong> your </br> workflow</div>
                                </div>
                                </div>

                      
                        </div>

                        </div>
                        </div>
</div>






                        <!--first parallax-->
                        <div id="pstparallaxcmsblock" class="block parallax" > 
                        <div class="container">	
                        <div class="row">
                        <div class="parallax-wrapper ">
                                      <div class="parallax-text col-6-medium col-12-small">
                                         <div class="text1">Increase output </br> efficiancy</div>
                                         <div class="text2">our web products bring your online presence to the century. No more degradation of work output</div>
                                     </div>
                        <div class="parallax-image col-6-medium col-12-small">
                                 <img src="<?php bloginfo('template_directory'); ?>/images/Webathon_tech girl.png" alt="alt text" />
                        </div>
                        </div>

                        </div>
                        </div>

                        <!--secound parallax-->
                        <div id="pstparallaxcmsblock-sec" class="block parallax" > 
                        <div class="container">	

                        <div class="parallax-wrapper">

                        <div class="parallax-image-sec col-6-medium col-12-small">
                                 <img src="<?php bloginfo('template_directory'); ?>/images/Webathon_family around computer.png" alt="alt text" />
                        </div>
                                      <div class="parallax-text-sec col-6-medium col-12-small">
                                         <div class="text1">Earn the respect </br>of your peers</div>
                                         <div class="text2">9 in 10 of our customers report a stronger reputation among their colleagues,friends and family.</div>
                                     </div>
                       
                        </div>

                        </div>
                        </div>

                        <!--third parallax-->
                        <div id="pstparallaxcmsblock" class="block parallax" > 
                        <div class="container">	

                        <div class="parallax-wrapper">
                                      <div class="parallax-text col-6-medium col-12-small">
                                         <div class="text1">Follow your </br>dream</div>
                                         <div class="text2">The tide is high and you're holding on.we want to be your number one web service provider.</div>
                                     </div>
                        <div class="parallax-image col-6-medium col-12-small">
                                 <img src="<?php bloginfo('template_directory'); ?>/images/Webathon_handshake.png" alt="alt text" />
                        </div>
                        </div>

                        </div>
                        </div>
    
</div>
                    

                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php get_footer(); ?>

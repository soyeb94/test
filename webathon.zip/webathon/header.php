<!DOCTYPE HTML>
<html>
	<head>
		<title>webathon</title>
		<meta charset="utf-8" />
		<meta name="viewport" content="width=device-width, initial-scale=1, user-scalable=no" />
		<?php wp_head() ?>
	</head>
	<body class="homepage is-preload">
		<div id="page-wrapper">

			<!-- Header -->
				<div id="header-wrapper">
					<div class="container">

						<!-- Header -->
							<header id="header">
								<div class="inner">

									<!-- Logo -->
                                    
                                     <div class="header_logo hidden-md-down" id="_desktop_logo">
                                         <img src="<?php bloginfo('template_directory'); ?>/images/Webathon_logo.png" alt="alt text" />
                                     </div>
									<!-- Nav -->
										<nav id="nav">
											<ul>
												<li><a href="#">About us</a></li>
												<li><a href="#">Products</a></li>
												<li><a href="#">Careers</a></li>
												<li><a href="#">Contact</a></li>
											</ul>
										</nav>

								</div>
                            </header>
</div>
</div>
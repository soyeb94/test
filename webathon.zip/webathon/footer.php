			<!-- Footer Wrapper -->
            <div id="footer-wrapper">
					<footer id="footer" class="container">
						<div class="row">
							<div class="col-2 col-6-medium col-12-small">

								<!-- Links -->
                                <section>
										<h2>About us</h2>
										<ul class="divided">
											<li><a href="#">Who we are</a></li>
											<li><a href="#">Our goal</a></li>
										</ul>
									</section>
							</div>
							<div class="col-2 col-6-medium col-12-small">

								<!-- Links -->
									<section>
										<h2>Products</h2>
										<ul class="divided">
											<li><a href="#">Web solution</a></li>
                                            <li><a href="#">Web tool</a></li>
                                            <li><a href="#">Basic package</a></li>
											<li><a href="#">Pro Package</a></li>
										</ul>
                                    </section>
                                
                            </div>
                            <div class="col-2 col-6-medium col-12-small">
								<!-- Links -->
									<section>
										<h2>careers</h2>
										<ul class="divided">
											<li><a href="#">Internal</a></li>
											<li><a href="#">Freelance</a></li>
										
										</ul>
									</section>

                            </div>
                            <div class="col-2 col-6-medium col-12-small">
								<!-- Links -->
									<section>
										<h2>Social</h2>
										<ul class="divided">
											<li><a href="#">Facebook</a></li>
											<li><a href="#">Twitter</a></li>
                                            <li><a href="#">instagram</a></li>
										</ul>
									</section>

                            </div>
                            
                             <div class="col-4 col-6-medium col-12-small">
								<!-- Links -->
									<section>
										<h2>Contact</h2>
										<ul class="divided">
											<li><a href="#">Customer Support</a></li>
											<li><a href="#">Business</a></li>
                                           
										</ul>
									</section>

							</div>
						
							<div class="col-12">
								<div id="copyright">
                                    <div class="footer_logo hidden-md-down" id="_desktop_logo">
                                         <img src="<?php bloginfo('template_directory'); ?>/images/Webathon_logo.png" alt="alt text" />
                                    </div>
                                     <p>This is some made up copyright stuff.Our lawyers are working around the clock to ensure this</br> text remains relevant so our editors don't have to bother keeping up to date. </p>
								</div>
							</div>
						</div>
					</footer>
				</div>

		</div>


            <?php wp_footer() ?>
	</body>
</html>